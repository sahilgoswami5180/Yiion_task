<?php $__env->startSection('content'); ?>
<h1>Create User</h1>
<form action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <!-- Add form fields similar to the edit form -->
    <button type="submit">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\yiion_task\resources\views///users/create.blade.php ENDPATH**/ ?>