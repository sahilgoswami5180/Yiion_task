<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <title>Test App</title>
</head>
<body>
    <header class="bg-dark text-white py-3">
        <div class="container">
            <nav class="d-flex justify-content-between align-items-center">
                <a href="<?php echo e(route('users.index')); ?>" class="text-white text-decoration-none h3">Test App</a>
                <div>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Home</a>
                </div>
            </nav>
        </div>
    </header>

    <main class="container mt-5">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</body>
</html>
<?php /**PATH C:\Users\Admin\yiion_task\resources\views/layout.blade.php ENDPATH**/ ?>