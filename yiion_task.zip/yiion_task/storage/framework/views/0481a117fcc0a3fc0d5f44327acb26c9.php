<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">User List</h1>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">Create New User</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>City</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->phonenumber); ?></td>
                <td><?php echo e($user->city); ?></td>


                <td>
                    <?php if($user->profilepicture): ?>
                        <img src="<?php echo e(Storage::url($user->profilepicture)); ?>" alt="Profile Picture" style="width: 50px; height: 50px; object-fit: cover;">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </td>

                <td>
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                    </form>
                    <a href="<?php echo e(route('users.sendMail', $user->id)); ?>" class="btn btn-primary btn-sm">Send Mail</a>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\yiion_task\resources\views/users/index.blade.php ENDPATH**/ ?>