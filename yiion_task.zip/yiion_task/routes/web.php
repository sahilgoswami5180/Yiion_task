<?php

use App\Http\Controllers\MyUserController;
use App\Models\MyUser;
use Illuminate\Support\Facades\Route;

// Default route for home
Route::get('/', function () {
    return view('./users/index');
});

Route::get('/', [MyUserController::class, 'index'])->name('home');
Route::get('/users', [MyUserController::class, 'index'])->name('users.index');
Route::get('/users/create', [MyUserController::class, 'create'])->name('users.create');
Route::post('/users', [MyUserController::class, 'store'])->name('users.store');
Route::get('/users/{user}', [MyUserController::class, 'show'])->name('users.show');
Route::get('/users/{user}/edit', [MyUserController::class, 'edit'])->name('users.edit');
Route::put('/users/{user}', [MyUserController::class, 'update'])->name('users.update');
Route::patch('/users/{user}', [MyUserController::class, 'update'])->name('users.update');
Route::delete('/users/{user}', [MyUserController::class, 'destroy'])->name('users.destroy');
Route::get('/users/{id}/send-mail', [MyUserController::class, 'sendMail'])->name('users.sendMail');
