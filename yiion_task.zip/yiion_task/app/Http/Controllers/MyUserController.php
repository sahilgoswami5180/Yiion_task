<?php

namespace App\Http\Controllers;

use App\Mail\UserNotificationMail;
use Illuminate\Support\Facades\Storage;

use App\Models\MyUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MyUserController extends Controller
{
    public function index()
    {
        $users = MyUser::all();
        return view('users.index', compact('users'));
    }

    public function create()
    {
        return view('users.create');
    }

    public function store(Request $request)
{
    $validatedData = $request->validate([
        'firstname' => 'required|string|max:255',
        'lastname' => 'required|string|max:255',
       'email' => [
    'required',
    'email',
    'unique:my_users,email,',
    'regex:/^[a-zA-Z0-9._%+-]+@([a-zA-Z0-9.-]+\.)?(com|in|outlook)$/'
],
'email.regex' => 'The email must end with .com, .in, or contain .outlook.',

        'phonenumber' => 'required|digits:10',
        'gender' => 'required|in:male,female',
        'city' => 'required|string',
        'profilepicture' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        'hobbies' => 'required|array',
        'hobbies.*' => 'string',
        'address' => 'required|string',
    ]);

    $validatedData['profilepicture'] = $request->file('profilepicture')->store('profiles');
    $validatedData['hobbies'] = json_encode($validatedData['hobbies']);

    MyUser::create($validatedData);

    return redirect()->route('users.index')->with('success', 'User created successfully!');
}


    public function show(MyUser $user)
    {
        return view('users.show', compact('user'));
    }

    public function edit(MyUser $user)
    {
        return view('users.edit', compact('user'));
    }

    public function update(Request $request, MyUser $user)
{
    $validated = $request->validate([
        'firstname' => 'required|string|max:255',
        'lastname' => 'required|string|max:255',
'email' => [
    'required',
    'email',
    'unique:my_users,email,' . $user->id,
    'regex:/^[a-zA-Z0-9._%+-]+@([a-zA-Z0-9.-]+\.)?(com|in|outlook)$/'
],
'email.regex' => 'The email must end with .com, .in, or contain .outlook.',

        'phonenumber' => 'required|digits:10',
        'gender' => 'required|in:male,female',
        'city' => 'required|string',
        'profilepicture' => 'nullable|image|mimes:jpg,jpeg,png|max:5120',
        'hobbies' => 'required|array',
        'address' => 'required|string',
    ]);

    // Handle profile picture upload
    if ($request->hasFile('profilepicture')) {
        Storage::disk('public')->delete($user->profilepicture);
        $validated['profilepicture'] = $request->file('profilepicture')->store('profiles', 'public');
    }

    // Encode hobbies before saving
    $validated['hobbies'] = json_encode($validated['hobbies']);

    // Update the user
    $user->update($validated);

    return redirect()->route('users.index')->with('success', 'User updated successfully.');
}


    public function destroy(MyUser $user)
    {
        Storage::disk('public')->delete($user->profilepicture);
        $user->delete();

        return redirect()->route('users.index')->with('success', 'User deleted successfully.');
    }

    public function sendMail($id)
    {
        $user = MyUser::findOrFail($id);

        Mail::to($user->email)->send(new UserNotificationMail($user));

        return redirect()->route('users.index')->with('success', 'Mail sent successfully!');
    }
}
