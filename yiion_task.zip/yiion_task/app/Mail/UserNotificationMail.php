<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UserNotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user; 

    /**
     * Create a new message instance.
     *
     * @param \App\Models\User $user
     */
    public function __construct($user)
    {
        $this->user = $user; 
    }

    /**
     * Build the message.
     */
    public function build()
    {
        return $this->subject('Abc pvt. Ltd')
                    ->view('emails.user_notification')
                    ->with(['user' => $this->user]);
    }
}
