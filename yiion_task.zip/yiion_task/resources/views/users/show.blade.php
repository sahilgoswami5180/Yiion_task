@extends('layout')

@section('content')
<div class="user-details">
    <h1>User Details</h1>
    <a href="{{ route('users.index') }}">Back to User List</a>

    <table>
        <tr>
            <th>First Name:</th>
            <td>{{ $user->firstname }}</td>
        </tr>
        <tr>
            <th>Last Name:</th>
            <td>{{ $user->lastname }}</td>
        </tr>
        <tr>
            <th>Email:</th>
            <td>{{ $user->email }}</td>
        </tr>
        <tr>
            <th>Phone Number:</th>
            <td>{{ $user->phonenumber }}</td>
        </tr>
        <tr>
            <th>Gender:</th>
            <td>{{ ucfirst($user->gender) }}</td>
        </tr>
        <tr>
            <th>City:</th>
            <td>{{ $user->city }}</td>
        </tr>
        <tr>
            <th>Profile Picture:</th>
            <td>
                <img src="{{ asset('storage/' . $user->profilepicture) }}" alt="Profile Picture" width="150">
            </td>
        </tr>
        <tr>
            <th>Hobbies:</th>
            <td>
                @foreach(json_decode($user->hobbies) as $hobby)
                    <span>{{ $hobby }}</span><br>
                @endforeach
            </td>
        </tr>
        <tr>
            <th>Address:</th>
            <td>{{ $user->address }}</td>
        </tr>
    </table>

    <div class="actions">
        <a href="{{ route('users.edit', $user->id) }}">Edit</a>
        <form action="{{ route('users.destroy', $user->id) }}" method="POST" style="display:inline;">
            @csrf
            @method('DELETE')
            <button type="submit">Delete</button>
        </form>
    </div>
</div>
@endsection
