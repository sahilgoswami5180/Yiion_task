@extends('layout')

@section('content')
<div class="container mt-5">
    <h1 class="mb-4">User List</h1>
    <a href="{{ route('users.create') }}" class="btn btn-primary mb-3">Create New User</a>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>City</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)
            <tr>
                <td>{{ $user->firstname }} {{ $user->lastname }}</td>
                <td>{{ $user->email }}</td>
                <td>{{ $user->phonenumber }}</td>
                <td>{{ $user->city }}</td>


                <td>
                    @if($user->profilepicture)
                        <img src="{{ Storage::url($user->profilepicture) }}" alt="Profile Picture" style="width: 50px; height: 50px; object-fit: cover;">
                    @else
                        <span>No Image</span>
                    @endif
                </td>

                <td>
                    <a href="{{ route('users.edit', $user->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('users.destroy', $user->id) }}" method="POST" class="d-inline">
                        @csrf @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                    </form>
                    <a href="{{ route('users.sendMail', $user->id) }}" class="btn btn-primary btn-sm">Send Mail</a>
                </td>

            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
