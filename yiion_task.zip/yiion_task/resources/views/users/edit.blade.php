@extends('layout')

@section('content')
<div class="container mt-5">
    <h1 class="mb-4">Edit User</h1>
    <form action="{{ route('users.update', $user->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="firstname" class="form-label">First Name <span style="color:red;">*</span></label>
                <input type="text" id="firstname" name="firstname" class="form-control @error('firstname') is-invalid @enderror" value="{{ old('firstname', $user->firstname) }}">
                @error('firstname')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="lastname" class="form-label">Last Name <span style="color:red;">*</span></label>
                <input type="text" id="lastname" name="lastname" class="form-control @error('lastname') is-invalid @enderror" value="{{ old('lastname', $user->lastname) }}">
                @error('lastname')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="email" class="form-label">Email <span style="color:red;">*</span></label>
                <input type="email" id="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email', $user->email) }}">
                @error('email')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="phonenumber" class="form-label">Phone Number <span style="color:red;">*</span></label>
                <input type="text" id="phonenumber" name="phonenumber" class="form-control @error('phonenumber') is-invalid @enderror"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);" maxlength="10" value="{{ old('phonenumber', $user->phonenumber) }}">
                @error('phonenumber')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Gender <span style="color:red;">*</span></label>
                <div class="form-check form-check-inline">
                    <input type="radio" id="male" name="gender" value="male" class="form-check-input @error('gender') is-invalid @enderror" {{ old('gender', $user->gender) == 'male' ? 'checked' : '' }}>
                    <label for="male" class="form-check-label">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" id="female" name="gender" value="female" class="form-check-input @error('gender') is-invalid @enderror" {{ old('gender', $user->gender) == 'female' ? 'checked' : '' }}>
                    <label for="female" class="form-check-label">Female</label>
                </div>
                @error('gender')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="city" class="form-label">City <span style="color:red;">*</span></label>
                <select id="city" name="city" class="form-select @error('city') is-invalid @enderror">
                    <option value="">Select City</option>
                    <option value="New York" {{ old('city', $user->city) == 'New York' ? 'selected' : '' }}>New York</option>
                    <option value="Los Angeles" {{ old('city', $user->city) == 'Los Angeles' ? 'selected' : '' }}>Los Angeles</option>
                    <option value="Chicago" {{ old('city', $user->city) == 'Chicago' ? 'selected' : '' }}>Chicago</option>
                </select>
                @error('city')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label for="profilepicture" class="form-label">Profile Picture</label>
                @if($user->profilepicture)
                    <div class="mb-2">
                        <img src="{{ Storage::url($user->profilepicture) }}" alt="Profile Picture" style="width: 100px; height: 100px; object-fit: cover; border-radius: 5px;">
                    </div>
                @endif
                <input type="file" id="profilepicture" name="profilepicture" class="form-control @error('profilepicture') is-invalid @enderror" accept="image/*">
                @error('profilepicture')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>

            <div class="col-md-6">
                <label class="form-label">Hobbies <span style="color:red;">*</span></label>
                <div class="form-check form-check-inline">
                    <input type="checkbox" id="hobby_reading" name="hobbies[]" value="Reading" class="form-check-input @error('hobbies') is-invalid @enderror"
                        {{ in_array('Reading', old('hobbies', json_decode($user->hobbies, true) ?? [])) ? 'checked' : '' }}>
                    <label for="hobby_reading" class="form-check-label">Reading</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="checkbox" id="hobby_gaming" name="hobbies[]" value="Gaming" class="form-check-input @error('hobbies') is-invalid @enderror"
                        {{ in_array('Gaming', old('hobbies', json_decode($user->hobbies, true) ?? [])) ? 'checked' : '' }}>
                    <label for="hobby_gaming" class="form-check-label">Gaming</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="checkbox" id="hobby_traveling" name="hobbies[]" value="Traveling" class="form-check-input @error('hobbies') is-invalid @enderror"
                        {{ in_array('Traveling', old('hobbies', json_decode($user->hobbies, true) ?? [])) ? 'checked' : '' }}>
                    <label for="hobby_traveling" class="form-check-label">Traveling</label>
                </div>
                @error('hobbies')
                    <span class="text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>

        <div class="mb-3">
            <label for="address" class="form-label">Address <span style="color:red;">*</span></label>
            <textarea id="address" name="address" class="form-control @error('address') is-invalid @enderror">{{ old('address', $user->address) }}</textarea>
            @error('address')
                <span class="text-danger">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </form>
</div>

<script>
    $(document).ready(function() {
        $('input, select, textarea').on('input change', function() {
            $(this).removeClass('is-invalid');
            $(this).next('.text-danger').remove();
        });
    });
</script>

@endsection
